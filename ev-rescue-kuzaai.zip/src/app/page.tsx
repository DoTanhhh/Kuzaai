import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PhoneCall, MapPin, Clock } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 px-4 py-8">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-2">Dịch Vụ Cứu Hộ Xe Điện KUZAAI</h1>
        <p className="text-lg">Hỗ trợ tận nơi 24/7 – Có mặt sau 15 phút</p>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardContent>
            <h2 className="text-2xl font-semibold mb-4">Dịch vụ của chúng tôi</h2>
            <ul className="list-disc list-inside space-y-1">
              <li>Cứu hộ xe máy điện, xe đạp điện tận nơi</li>
              <li>Sạc pin tại chỗ – nhanh chóng an toàn</li>
              <li>Hỗ trợ các dòng xe VinFast, Xmen, Dibao, Yamaha, v.v.</li>
              <li>Kéo xe về trung tâm sửa chữa nếu cần</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <h2 className="text-2xl font-semibold mb-4">Thông tin liên hệ</h2>
            <div className="flex items-center gap-2 mb-2">
              <PhoneCall className="text-blue-600" />
              <span className="font-medium">0972 261 990</span>
            </div>
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="text-green-600" />
              <span>3a ngõ 430 Bạch Đằng, Hà Nội</span>
            </div>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="text-yellow-600" />
              <span>Hỗ trợ 24/7</span>
            </div>
            <Button className="w-full">Gọi cứu hộ ngay</Button>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center mt-12 text-sm text-gray-500">
        © 2025 KUZAAI - Dịch vụ cứu hộ xe điện
      </footer>
    </div>
  );
}
